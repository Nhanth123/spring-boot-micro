package api.spring.micro_brewery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroBreweryApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroBreweryApplication.class, args);
	}

}
