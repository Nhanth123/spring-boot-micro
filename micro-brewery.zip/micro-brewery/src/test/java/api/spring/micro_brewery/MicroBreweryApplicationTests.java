package api.spring.micro_brewery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroBreweryApplicationTests {

	@Test
	void contextLoads() {
	}

}
